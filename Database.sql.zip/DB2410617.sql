-- phpMyAdmin SQL Dump
-- version 4.2.12
-- http://www.phpmyadmin.net
--
-- Host: rdbms
-- Erstellungszeit: 25. Nov 2016 um 10:28
-- Server Version: 5.5.52-log
-- PHP-Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `DB2410617`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_card`
--

CREATE TABLE IF NOT EXISTS `cah_card` (
`card_id` int(11) NOT NULL,
  `text` varchar(100) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `is_black` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_cardcategory`
--

CREATE TABLE IF NOT EXISTS `cah_cardcategory` (
`id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_category`
--

CREATE TABLE IF NOT EXISTS `cah_category` (
`cat_id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_game`
--

CREATE TABLE IF NOT EXISTS `cah_game` (
`game_id` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT NULL,
  `game_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  `game_mode` int(11) NOT NULL DEFAULT '0',
  `target_score` int(11) DEFAULT NULL,
  `kicktimer` int(11) DEFAULT NULL,
  `host_user_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `cah_game`
--

INSERT INTO `cah_game` (`game_id`, `create_date`, `last_activity`, `game_name`, `state`, `game_mode`, `target_score`, `kicktimer`, `host_user_id`) VALUES
(1, '2016-11-18 15:06:04', NULL, 'CAH Game 1825519258', 1, 0, NULL, NULL, 10),
(2, '2016-11-18 15:08:03', NULL, 'CAH Game 1754759049', 0, 0, NULL, NULL, 10),
(3, '2016-11-18 15:08:45', NULL, 'CAH Game 318393380', 0, 0, NULL, NULL, 10),
(4, '2016-11-18 15:09:02', NULL, 'CAH Game 1942889286', 0, 0, NULL, NULL, 10),
(5, '2016-11-18 15:10:37', NULL, 'CAH Game 287998127', 0, 0, NULL, NULL, 10),
(6, '2016-11-18 15:10:49', NULL, 'CAH Game 659005004', 0, 0, NULL, NULL, 10),
(7, '2016-11-18 15:11:44', NULL, 'CAH Game 18703130', 0, 0, NULL, NULL, 10),
(8, '2016-11-18 15:13:34', NULL, 'CAH Game 1308254041', 0, 0, NULL, NULL, 10),
(9, '2016-11-18 15:16:59', NULL, 'CAH Game 1641128789', 0, 0, NULL, NULL, 10),
(10, '2016-11-18 15:32:44', NULL, 'CAH Game 924000320', 0, 0, NULL, NULL, 10),
(11, '2016-11-18 15:33:19', NULL, 'CAH Game 1956129300', 0, 0, NULL, NULL, 10),
(12, '2016-11-18 15:34:19', NULL, 'CAH Game 1966002726', 0, 0, NULL, NULL, 10),
(13, '2016-11-18 15:34:42', NULL, 'CAH Game 1505590215', 0, 0, NULL, NULL, 10),
(14, '2016-11-18 15:35:17', NULL, 'CAH Game 649353406', 0, 0, NULL, NULL, 10),
(15, '2016-11-18 15:37:43', NULL, 'CAH Game 420854231', 0, 0, NULL, NULL, 10),
(16, '2016-11-18 15:40:38', NULL, 'CAH Game 1741027180', 0, 0, NULL, NULL, 10),
(17, '2016-11-18 15:40:59', NULL, 'CAH Game 1313644318', 0, 0, NULL, NULL, 10),
(18, '2016-11-21 09:37:41', NULL, 'CAH Game 414002010', 0, 0, NULL, NULL, 10);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_gamecards`
--

CREATE TABLE IF NOT EXISTS `cah_gamecards` (
`id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_gameusers`
--

CREATE TABLE IF NOT EXISTS `cah_gameusers` (
`id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `cah_gameusers`
--

INSERT INTO `cah_gameusers` (`id`, `game_id`, `user_id`) VALUES
(1, 14, 16),
(2, 15, 16),
(3, 16, 21),
(4, 17, 22),
(5, 18, 23);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_migration`
--

CREATE TABLE IF NOT EXISTS `cah_migration` (
  `version` varchar(180) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `cah_migration`
--

INSERT INTO `cah_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1478878816),
('m130524_201442_init', 1478878827);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_user`
--

CREATE TABLE IF NOT EXISTS `cah_user` (
`user_id` int(11) NOT NULL,
  `generated_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `user_name` varchar(40) CHARACTER SET latin1 COLLATE latin1_german1_ci NOT NULL,
  `is_judge` tinyint(1) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `cah_user`
--

INSERT INTO `cah_user` (`user_id`, `generated_id`, `user_name`, `is_judge`, `score`, `last_activity`) VALUES
(3, '6a429afe0f293b234c44d1c41b826811', 'PEEEENIS', 0, 0, '2016-11-18 11:30:40'),
(4, '5ace4760e95388813510a9258e55c9e7', 'PEEEENIS', 0, 0, '2016-11-18 11:34:21'),
(5, 'c07102ebd66807cbb680b48685042702', 'PEEEENIS', 0, 0, '2016-11-18 11:34:40'),
(6, '65d1f275e1eb8ec530e692c4c14061a2', 'PEEEENIS', 0, 0, '2016-11-18 11:38:24'),
(7, 'd2a9383d8eea80a45c268ca77862ac49', 'PEEEENIS', 0, 0, '2016-11-18 11:39:50'),
(8, '64a740ef20710e51c066f5ecdf8e6a3a', 'PEEEENIS', 0, 0, '2016-11-18 11:44:08'),
(9, 'dfb0ee0a3d62088471e8f91105d41a81', 'PEEEENIS', 0, 0, '2016-11-18 11:44:49'),
(10, '9efb742a9e8c8a2b9e61a383379f4dcf', 'Lukas', 0, 0, '2016-11-18 12:01:06'),
(11, '3e42ac0ed83f6b653de955fbd9b0231d', 'Lukas', 0, 0, '2016-11-18 12:01:35'),
(12, '8afa36047e702a02062aebc43336b084', 'Player_01', 0, 0, '2016-11-18 14:12:48'),
(13, '1057da9ccc129ddfc8cac0bbd5dbea58', 'Player_01', 0, 0, '2016-11-18 14:14:23'),
(14, 'cc007358460bbc1ece4e8c8ef6380b22', 'Player_01', 0, 0, '2016-11-18 14:42:55'),
(15, '5aafbc529d7c826ef4c19a0341f079ad', 'Player_01', 0, 0, '2016-11-18 14:43:08'),
(16, '92fe60775d9799a127ba0dfc037881de', 'Player_01', 0, 0, '2016-11-18 14:37:43'),
(17, '79f1913f3e1603b71bbbc6faaf4fadf9', 'Player_01', 0, 0, '2016-11-18 14:53:53'),
(18, '91a0c6f9f3f56dc7d642547b1848a231', 'Player_01', 0, 0, '2016-11-18 14:16:59'),
(19, '3d071c3dfcad8d651db2433c6fe0e668', 'Player_01', 0, 0, '2016-11-18 14:32:44'),
(20, '321fa7221832b2135dd215c160dddc96', 'Player_01', 0, 0, '2016-11-18 14:34:42'),
(21, '711ed686db2e0220e92481bc4b5eba07', 'Player_01', 0, 0, '2016-11-18 14:40:38'),
(22, 'f561385f038d8cd0badacd6fd61ed18b', 'Player_01', 0, 0, '2016-11-18 14:40:59'),
(23, '8d1b05e5fe85eec4e128b08f3a68379b', 'Player_01', 0, 0, '2016-11-21 08:37:41');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cah_yii_user`
--

CREATE TABLE IF NOT EXISTS `cah_yii_user` (
`id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `cah_yii_user`
--

INSERT INTO `cah_yii_user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'rXhtrIMggIAv2JNzW-0MeZgLLAbgBJGq', '$2y$13$5p4Bhempz2LWWwKRr99IAOtmg6aEUBDFH1uVNsVX/hFATnQYyhMx6', NULL, '', 10, 0, 0),
(2, 'Carson', 'rXhtrIMggIAv2JNzW-0MeZgLLAbgBJGq', '$2y$13$5p4Bhempz2LWWwKRr99IAOtmg6aEUBDFH1uVNsVX/hFATnQYyhMx6', NULL, 'carson@cah.heretics.de', 10, 1478879831, 1478879831);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `cah_card`
--
ALTER TABLE `cah_card`
 ADD PRIMARY KEY (`card_id`);

--
-- Indizes für die Tabelle `cah_cardcategory`
--
ALTER TABLE `cah_cardcategory`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `card_id_2` (`card_id`,`cat_id`), ADD KEY `card_id` (`card_id`), ADD KEY `cat_id` (`cat_id`);

--
-- Indizes für die Tabelle `cah_category`
--
ALTER TABLE `cah_category`
 ADD PRIMARY KEY (`cat_id`);

--
-- Indizes für die Tabelle `cah_game`
--
ALTER TABLE `cah_game`
 ADD PRIMARY KEY (`game_id`), ADD KEY `host_user_id` (`host_user_id`);

--
-- Indizes für die Tabelle `cah_gamecards`
--
ALTER TABLE `cah_gamecards`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `game_id_3` (`game_id`,`card_id`), ADD KEY `game_id` (`game_id`), ADD KEY `user_id` (`user_id`), ADD KEY `card_id` (`card_id`);

--
-- Indizes für die Tabelle `cah_gameusers`
--
ALTER TABLE `cah_gameusers`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `game_id` (`game_id`,`user_id`), ADD KEY `game_id_2` (`game_id`), ADD KEY `user_id` (`user_id`);

--
-- Indizes für die Tabelle `cah_migration`
--
ALTER TABLE `cah_migration`
 ADD PRIMARY KEY (`version`);

--
-- Indizes für die Tabelle `cah_user`
--
ALTER TABLE `cah_user`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `generated_id` (`generated_id`);

--
-- Indizes für die Tabelle `cah_yii_user`
--
ALTER TABLE `cah_yii_user`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `cah_card`
--
ALTER TABLE `cah_card`
MODIFY `card_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `cah_cardcategory`
--
ALTER TABLE `cah_cardcategory`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `cah_category`
--
ALTER TABLE `cah_category`
MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `cah_game`
--
ALTER TABLE `cah_game`
MODIFY `game_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT für Tabelle `cah_gamecards`
--
ALTER TABLE `cah_gamecards`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `cah_gameusers`
--
ALTER TABLE `cah_gameusers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT für Tabelle `cah_user`
--
ALTER TABLE `cah_user`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT für Tabelle `cah_yii_user`
--
ALTER TABLE `cah_yii_user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `cah_cardcategory`
--
ALTER TABLE `cah_cardcategory`
ADD CONSTRAINT `cah_cardcategory_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `cah_category` (`cat_id`) ON DELETE CASCADE,
ADD CONSTRAINT `cah_cardcategory_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `cah_card` (`card_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `cah_game`
--
ALTER TABLE `cah_game`
ADD CONSTRAINT `cah_game_ibfk_1` FOREIGN KEY (`host_user_id`) REFERENCES `cah_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `cah_gamecards`
--
ALTER TABLE `cah_gamecards`
ADD CONSTRAINT `cah_gamecards_ibfk_3` FOREIGN KEY (`card_id`) REFERENCES `cah_card` (`card_id`) ON DELETE CASCADE,
ADD CONSTRAINT `cah_gamecards_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `cah_game` (`game_id`) ON DELETE CASCADE,
ADD CONSTRAINT `cah_gamecards_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `cah_user` (`user_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `cah_gameusers`
--
ALTER TABLE `cah_gameusers`
ADD CONSTRAINT `cah_gameusers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `cah_user` (`user_id`) ON DELETE CASCADE,
ADD CONSTRAINT `cah_gameusers_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `cah_game` (`game_id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
